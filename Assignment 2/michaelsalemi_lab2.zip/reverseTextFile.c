#include "reverseTextFile.h"

void createReversedTextFile(int rf, int wf) {
    int charCount, i;
    char buffer[1];
    char currentChar;

    charCount = lseek(rf, 0, SEEK_END);
    printf("%d: ", charCount);
    for (i = 0; i < charCount; i++) {
        lseek(rf, -(i+1), SEEK_END);
        read(rf, buffer, 1);
        currentChar = buffer[0];
        write(wf, currentChar, 1);
        printf("%c", currentChar);
    }
    printf("\n");
}