#include "reverseTextFile.h"

int main(int argc, char *argv[]) {
    int fd = open("./test.txt", O_RDONLY);
    int fd2 = open("./testReversed.txt", O_CREAT | O_RDWR);
    int fd3 = open("./testReReversed.txt", O_CREAT | O_WRONLY);

    createReversedTextFile(fd, fd2);
    createReversedTextFile(fd2, fd3);

    return 0;
}
