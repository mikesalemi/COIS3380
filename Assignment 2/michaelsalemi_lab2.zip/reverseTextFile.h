#ifndef REVERSETEXTFILE_H
#define REVERSETEXTFILE_H

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

void createReversedTextFile(int rf, int wf);

#endif