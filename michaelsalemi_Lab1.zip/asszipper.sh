#! /bin/bash

###################
# Assignment Zip Tool
# Michael Salemi - 0751614
# January 12, 2022
# Creates zip file based on files given as arguments and places zipped file in home directory
# Files must be in current working dirtectory
# Usage: asszipper zipname file1 file2 file3...
#	 created zip will be created in user's home direcrory as $USER_zipname.zip
###################

if [ $# -eq 0 ] # executes if no arguments given
then
	echo "EXIT_ERROR: No Arguments given after command call." # descriptive error message
	exit 1 # exit with error code 1
fi

ZIPNAME=~/${USER}_$1 # usesusers home directory for location and users name/ argument 1 as zip file name

if [ $# -eq 1 ] # executes if only 1 argument given
then
	echo "EXIT_ERROR: Cannot create empty zip file named $ZIPNAME" # descriptive error message
	echo "            Must specify file names after first argument" # descriptive error message continued
	exit 1 # exit with error code 1
fi


for file in  "${@:2}" # iterates through all arguments given after first argument
do
	if [ $(ls -d $file 2> /dev/null | wc -l) -eq 0 ] # checks to see if given argument is a file that exists
	then
		echo "EXIT_ERROR: $file was not found." # descriptive error message for file finding error
	 	exit 1 # exit with error code 1
	else
		echo "FOUND: $file" # confirmation of file existing and being found at given location
	fi
done
FILELIST=("${@:2}") # adds all given files to list of files to be zipped
echo Files Included: ${FILELIST[@]} # user prompt for all files to be zipped
echo Zip Location: $ZIPNAME # confirmation prompt of zip name and location
zip -r $ZIPNAME ${FILELIST[@]} # zips files and places the zip in users home directory

exit 0 # successful exit from program
